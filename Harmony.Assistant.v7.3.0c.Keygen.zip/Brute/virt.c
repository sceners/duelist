#include "md5.h"
#include "stdio.h"

void main(void)
{
	char   *strbuff;
	unsigned int  k;
	unsigned char md[MD5_DIGEST_LENGTH];
	MD5_CTX MDCTX;
	static unsigned char rawData[16] =
	{
	    0x44, 0xC6, 0x81, 0x53, 0x90, 0xE3, 0x9E, 0x66, 0xAE, 0x42, 0x26, 0x0B, 0x6A, 0x70, 0x22, 0x93,
	};

	strbuff=bd_init("ABCDEFGHIJKLKMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789. !:?", 5);

	printf("\n%lu possible combos\n\n", bd_getcombonum());

	while(bd_next())
	{
		MD5_Init(&MDCTX);
		MD5_Update(&MDCTX, (unsigned char*)strbuff, 5);
		MD5_Final(md, &MDCTX);

		if (memcmp(rawData, md, 16)==0)
			__asm int 3
	}		
}