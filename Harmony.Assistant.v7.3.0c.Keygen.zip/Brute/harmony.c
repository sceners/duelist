#include "md5.h"

void main(void)
{
	unsigned long i;
	unsigned int  k;
	unsigned char md[MD5_DIGEST_LENGTH];
	MD5_CTX MDCTX;

	for (k=0; k<0xFFFFFFFF; k++)
	{
		MD5_Init(&MDCTX);
		MD5_Update(&MDCTX, (unsigned char*)&k, 4);
		MD5_Final(md, &MDCTX);

		i =*((unsigned long*)(md   ));
		i^=*((unsigned long*)(md+ 4));
		i^=*((unsigned long*)(md+ 8));
		i^=*((unsigned long*)(md+12));

		if (i==0x101A7014)
// 0x14701A10
			__asm int 3
	}
}