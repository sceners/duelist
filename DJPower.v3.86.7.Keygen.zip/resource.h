//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Keymaker.rc
//
#define IDD_MAINDLG                     131
#define IDD_ABOUTDLG                    132
#define IDB_MAINBMP                     133
#define IDI_MAINICON                    134
#define IDC_NAME                        1000
#define IDC_SERIAL                      1001
#define IDC_ABOUT                       1002
#define IDC_EXIT                        1003
#define IDC_SHOWBMP                     1004
#define IDC_CLOSE                       1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
