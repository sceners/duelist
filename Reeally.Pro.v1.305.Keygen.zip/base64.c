void ToBase64(char szInput[3], char szOutput[4], int nLen)
{
	unsigned char szBuf[3];
	char 	      BASE64_CODE[] = "+-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

	memset(szBuf, '\0', 3);
	memcpy(szBuf, szInput, nLen);
	
	szOutput[0] = BASE64_CODE[szBuf[0] >> 2];
	szOutput[1] = BASE64_CODE[(szBuf[0] & 0x03) << 4 | szBuf[1] >> 4];
	if (nLen >= 2)
		szOutput[2] = BASE64_CODE[(szBuf[1] & 0x0f) << 2 | szBuf[2] >> 6];
	else
		szOutput[2] = 0;
	if (nLen == 3)
		szOutput[3] = BASE64_CODE[szBuf[2] & 0x3f];
	else
		szOutput[3] = 0;
}

void Base64Encode(char * szInput, int nLen, char * szOutput, int * pLen)
{
	int i;
	char szBuf[5];
		
	szBuf[4] = '\0';
	szOutput[0] = '\0';

	*pLen = 0;

	for (i = 0; i < nLen; i += 3)
	{
		ToBase64(szInput + i, szBuf, min(nLen - i, 3));
		lstrcat(szOutput, szBuf);
		*pLen += 4;
	}
}